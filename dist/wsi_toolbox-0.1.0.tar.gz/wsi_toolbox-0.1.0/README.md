# WSI Toolbox

A comprehensive toolkit for Whole Slide Image (WSI) processing, feature extraction, and clustering analysis.

## Installation

### From PyPI

```bash
pip install wsi-toolbox
```

### With optional dependencies

```bash
# For slide-level encoding (gigapath)
pip install wsi-toolbox[gigapath]
```

### For development

```bash
# Clone repository
git clone https://github.com/endaaman/WSI-toolbox.git
cd WSI-toolbox

# Install dependencies
uv sync

# For gigapath slide encoder
uv sync --extra gigapath
```

## Quick Start

### As a Python Library

See [README_API.md](README_API.md) for comprehensive API documentation.

```python
import wsi_toolbox as wt

# Configure
wt.set_default_model('uni')
wt.set_default_progress('tqdm')

# Convert WSI to HDF5
cmd = wt.Wsi2HDF5Command(patch_size=256, rotate=True)
result = cmd('input.ndpi', 'output.h5')

# Extract features
wt.set_default_device('cuda')
emb_cmd = wt.PatchEmbeddingCommand(batch_size=256)
emb_result = emb_cmd('output.h5')

# Clustering
cluster_cmd = wt.ClusteringCommand(resolution=1.0, use_umap=True)
cluster_result = cluster_cmd(['output.h5'])

# Visualize
umap_embs = cluster_cmd.get_umap_embeddings()
fig = wt.plot_umap(umap_embs, cluster_cmd.total_clusters)
fig.savefig('umap.png')
```

### As a CLI Tool

```bash
# Convert WSI to HDF5
wsi-toolbox wsi2h5 --in data/sample.ndpi --out output.h5 --patch-size 256

# Extract features
wsi-toolbox embed --in output.h5 --model uni --batch-size 256

# Clustering
wsi-toolbox cluster --in output.h5 --model uni --resolution 1.0

# Preview clusters
wsi-toolbox preview --in output.h5 --model uni

# For help on any command
wsi-toolbox <command> --help
```

### Streamlit Web Application

```bash
# Start web app
uv run task app

# Or directly
streamlit run wsi_toolbox/app.py
```

## HDF5 File Structure

WSI-toolbox stores all data in a single HDF5 file with the following structure:

```
output.h5
├── patches                      # Patch images [N, H, W, 3]
├── coordinates                  # Patch coordinates [N, 2]
├── metadata/
│   ├── original_mpp            # Original microns per pixel
│   ├── mpp                     # Output patch MPP
│   ├── scale                   # Scale factor
│   ├── patch_size              # Patch size (e.g., 256)
│   ├── patch_count             # Total patches
│   ├── cols                    # Grid columns
│   └── rows                    # Grid rows
├── {model}/                    # e.g., "uni", "gigapath", "virchow2"
│   ├── features                # Features [N, D]
│   ├── latent_features         # Latent features [N, K, K, D] (optional)
│   └── clusters                # Cluster labels [N]
```

## Available Models

- **UNI**: UNI foundation model (1024-D features)
- **Gigapath**: Prov-Gigapath (1536-D features)
- **Virchow2**: Virchow2 (2560-D features)

## Features

- **WSI Processing**: Convert .ndpi, .svs, .tiff to HDF5 patches
- **Feature Extraction**: Support for UNI, Gigapath, Virchow2 models
- **Clustering**: Leiden clustering with UMAP visualization
- **Preview**: Generate cluster overlays and latent PCA visualizations
- **Command Pattern**: Reusable, type-safe command classes
- **Pydantic Results**: Type-safe result objects
- **Progress Tracking**: Support for tqdm and Streamlit progress bars

## Documentation

- [API Guide](README_API.md) - Comprehensive Python API documentation
- [CLAUDE.md](CLAUDE.md) - Development guidelines

## License

MIT
